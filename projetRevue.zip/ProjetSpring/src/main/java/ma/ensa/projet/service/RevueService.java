package ma.ensa.projet.service;

import ma.ensa.projet.domain.Revue;

import java.util.List;

public interface RevueService  {
    public List<Revue> findAll();
}
