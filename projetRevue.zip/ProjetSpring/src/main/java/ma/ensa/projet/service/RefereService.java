package ma.ensa.projet.service;

import ma.ensa.projet.domain.Article;
import ma.ensa.projet.domain.Commentaire;
import ma.ensa.projet.domain.Refere;

import java.util.List;

public interface RefereService {
    public List<Refere> findAll();




}
