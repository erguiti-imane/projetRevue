package ma.ensa.projet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetRevueApplicationTests {

    @Test
    void contextLoads() {
    }

}
